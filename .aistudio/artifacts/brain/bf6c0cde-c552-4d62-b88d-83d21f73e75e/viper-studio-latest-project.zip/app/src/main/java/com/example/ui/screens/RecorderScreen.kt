package com.example.ui.screens

import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.FpsOption
import com.example.data.model.RecordingItem
import com.example.data.model.ResolutionOption
import com.example.engine.recording.ScreenRecorderManager
import com.example.ui.ViperStudioViewModel
import com.example.ui.theme.RecordingRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ViperCyan
import com.example.ui.theme.ViperGreen
import com.example.ui.theme.ViperSurfaceCard
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecorderScreen(
    viewModel: ViperStudioViewModel,
    onStartRecordRequest: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val recordingState by viewModel.recordingState.collectAsState()
    val recordingError by viewModel.recordingErrorMessage.collectAsState()
    val isRecording by viewModel.isRecording.collectAsState()
    val isPaused by viewModel.isRecordingPaused.collectAsState()
    val durationSec by viewModel.recordingDurationSec.collectAsState()
    val estimatedSizeBytes by viewModel.estimatedRecordingSizeBytes.collectAsState()
    val availableStorageGb by viewModel.availableStorageGb.collectAsState()
    val lastSavedRecording by viewModel.lastSavedRecording.collectAsState()
    val streamConfig by viewModel.streamConfig.collectAsState()
    val recordings by viewModel.recordingsList.collectAsState()
    val audioConfig by viewModel.audioConfig.collectAsState()
    val context = LocalContext.current

    val infiniteTransition = rememberInfiniteTransition(label = "rec_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rec_alpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0E17))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Finalizing Progress Indicator Banner
        AnimatedVisibility(
            visible = recordingState == ScreenRecorderManager.RecordingState.STOPPING,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("finalizing_recording_card"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14243B)),
                border = androidx.compose.foundation.BorderStroke(1.dp, ViperCyan),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = ViperCyan,
                        strokeWidth = 2.5.dp
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "FINALIZING & SAVING RECORDING...",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            color = ViperCyan,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Draining encoder frames & saving MP4 to Movies/VIPER STUDIO",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Recording Error Banner
        AnimatedVisibility(
            visible = recordingError != null || recordingState == ScreenRecorderManager.RecordingState.ERROR,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            recordingError?.let { err ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("recording_error_banner"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1218)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF5252)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(20.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "RECORDING FAILED",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFF5252)
                            )
                            Text(
                                text = err,
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                        IconButton(
                            onClick = { viewModel.dismissRecordingError() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Saved Confirmation Banner (Movies/VIPER STUDIO)
        AnimatedVisibility(
            visible = (recordingState == ScreenRecorderManager.RecordingState.SAVED || lastSavedRecording != null) && recordingState != ScreenRecorderManager.RecordingState.STOPPING,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            lastSavedRecording?.let { savedItem ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("saved_recording_banner"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2B1E)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ViperGreen),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ViperGreen, modifier = Modifier.size(20.dp))
                                Text(
                                    text = "RECORDING SAVED SUCCESSFULLY",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = ViperGreen,
                                    letterSpacing = 1.sp
                                )
                            }
                            IconButton(
                                onClick = { viewModel.dismissSavedRecordingBanner() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted, modifier = Modifier.size(16.dp))
                            }
                        }

                        Text(
                            text = "Saved to Movies/VIPER STUDIO • Ready in Gallery",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ViperGreen
                        )

                        Text(
                            text = savedItem.filePath,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${savedItem.durationSeconds}s • ${String.format(Locale.getDefault(), "%.1f", savedItem.fileSizeBytes / (1024.0 * 1024.0))} MB • ${savedItem.resolution}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        playRecordingFile(context, savedItem.filePath)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ViperGreen, contentColor = Color.Black),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(34.dp).testTag("open_video_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("OPEN VIDEO", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        shareRecordingFile(context, savedItem.filePath)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(34.dp).testTag("share_video_button")
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, tint = ViperCyan, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("SHARE", color = ViperCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Hero Recording Control Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ViperSurfaceCard),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Status Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    recordingState == ScreenRecorderManager.RecordingState.STOPPING -> ViperCyan
                                    isRecording -> RecordingRed
                                    else -> Color.Gray
                                }
                            )
                            .alpha(if (isRecording && !isPaused) pulseAlpha else 1f)
                    )
                    Text(
                        text = when {
                            recordingState == ScreenRecorderManager.RecordingState.STOPPING -> "FINALIZING RECORDING (MP4)"
                            isRecording -> if (isPaused) "RECORDING PAUSED" else "RECORDING ACTIVE (MP4)"
                            else -> "SCREEN RECORDER STANDBY"
                        },
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        color = when {
                            recordingState == ScreenRecorderManager.RecordingState.STOPPING -> ViperCyan
                            isRecording -> RecordingRed
                            else -> ViperCyan
                        },
                        letterSpacing = 1.sp
                    )
                }

                // Digital Timer Clock
                val hours = durationSec / 3600
                val mins = (durationSec % 3600) / 60
                val secs = durationSec % 60
                val timeFormatted = if (hours > 0) {
                    String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, mins, secs)
                } else {
                    String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
                }

                Text(
                    text = timeFormatted,
                    fontSize = 42.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                // Storage and Size Indicators
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.SdCard, contentDescription = null, tint = ViperCyan, modifier = Modifier.size(14.dp))
                        Text(
                            text = "${String.format(Locale.getDefault(), "%.1f", availableStorageGb)} GB Free",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    if (isRecording) {
                        Text(
                            text = "•",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                        Text(
                            text = "Size: ${String.format(Locale.getDefault(), "%.1f", estimatedSizeBytes / (1024.0 * 1024.0))} MB",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ViperGreen
                        )
                    }

                    Text(
                        text = "•",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Folder, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                        Text(
                            text = "Movies/VIPER STUDIO",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                // Main Recorder Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (recordingState == ScreenRecorderManager.RecordingState.STOPPING) {
                        Button(
                            onClick = { },
                            enabled = false,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("stopping_recording_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF1E283A),
                                disabledContainerColor = Color(0xFF1E283A),
                                disabledContentColor = ViperCyan
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = ViperCyan,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("FINALIZING & SAVING...", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ViperCyan)
                        }
                    } else if (!isRecording) {
                        Button(
                            onClick = onStartRecordRequest,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("start_recording_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = RecordingRed, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.FiberManualRecord, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("START RECORDING", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    } else {
                        // Pause / Resume
                        Button(
                            onClick = {
                                if (isPaused) viewModel.resumeScreenRecording() else viewModel.pauseScreenRecording()
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283A), contentColor = TextPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isPaused) "RESUME" else "PAUSE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        // Stop & Save
                        Button(
                            onClick = { viewModel.stopScreenRecording() },
                            modifier = Modifier.weight(1f).height(48.dp).testTag("stop_recording_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = RecordingRed, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("STOP & SAVE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Recording Settings Pills (Resolution & FPS)
        if (!isRecording) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ViperSurfaceCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "RECORDING RESOLUTION & FPS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ResolutionOption.values().forEach { res ->
                            val isSelected = streamConfig.resolution == res
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) ViperCyan else Color(0xFF131A28))
                                    .border(1.dp, if (isSelected) ViperCyan else Color(0xFF243046), RoundedCornerShape(8.dp))
                                    .clickable { viewModel.setResolution(res) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = res.label.substringBefore(" "),
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.Black else TextPrimary
                                )
                            }
                        }

                        FpsOption.values().forEach { fps ->
                            val isSelected = streamConfig.fps == fps
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) ViperGreen else Color(0xFF131A28))
                                    .border(1.dp, if (isSelected) ViperGreen else Color(0xFF243046), RoundedCornerShape(8.dp))
                                    .clickable { viewModel.setFps(fps) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "${fps.value} FPS",
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.Black else TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Audio Sources for Recording (Game Audio vs Microphone)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ViperSurfaceCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "RECORDING AUDIO SOURCES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (audioConfig.isInternalAudioEnabled) Color(0xFF132A1C) else Color(0xFF131A28))
                                .border(1.dp, if (audioConfig.isInternalAudioEnabled) ViperGreen else Color(0xFF243046), RoundedCornerShape(8.dp))
                                .clickable { viewModel.toggleInternalAudio() }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (audioConfig.isInternalAudioEnabled) "Internal Audio: ON" else "Internal Audio: OFF",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (audioConfig.isInternalAudioEnabled) ViperGreen else TextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (audioConfig.isMicAudioEnabled) Color(0xFF0F2B30) else Color(0xFF131A28))
                                .border(1.dp, if (audioConfig.isMicAudioEnabled) ViperCyan else Color(0xFF243046), RoundedCornerShape(8.dp))
                                .clickable { viewModel.toggleMicAudio() }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (audioConfig.isMicAudioEnabled) "Microphone: ON" else "Microphone: OFF",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (audioConfig.isMicAudioEnabled) ViperCyan else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Saved Recordings List Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SAVED MP4 RECORDINGS (${recordings.size})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )
        }

        if (recordings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1522)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = null,
                        tint = Color(0xFF2D3C55),
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "No recordings saved yet",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Tap 'START RECORDING' to capture your mobile gameplay with internal audio to Movies/VIPER STUDIO.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 24.dp),
                        lineHeight = 15.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(recordings, key = { it.id }) { item ->
                    RecordingCardItem(
                        item = item,
                        onPlay = { playRecordingFile(context, item.filePath) },
                        onShare = { shareRecordingFile(context, item.filePath) },
                        onDelete = { viewModel.deleteRecording(item) }
                    )
                }
            }
        }
    }
}

private fun resolvePlayableUri(context: android.content.Context, filePath: String): Uri {
    if (filePath.startsWith("content://")) {
        return Uri.parse(filePath)
    }
    val file = File(filePath)
    if (file.exists()) {
        try {
            return FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        } catch (_: Exception) {}
    }
    // Query MediaStore by filename
    try {
        val cursor = context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Video.Media._ID),
            "${MediaStore.Video.Media.DISPLAY_NAME} = ?",
            arrayOf(file.name),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val id = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                return ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
            }
        }
    } catch (_: Exception) {}

    // Check staging recordings directory in app external storage
    try {
        val staging = File(context.getExternalFilesDir("recordings"), file.name)
        if (staging.exists()) {
            return FileProvider.getUriForFile(context, "${context.packageName}.provider", staging)
        }
    } catch (_: Exception) {}

    return if (file.exists()) Uri.fromFile(file) else Uri.parse(filePath)
}

private fun playRecordingFile(context: android.content.Context, filePath: String) {
    try {
        val uri = resolvePlayableUri(context, filePath)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "video/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open video player: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun shareRecordingFile(context: android.content.Context, filePath: String) {
    try {
        val uri = resolvePlayableUri(context, filePath)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share MP4 Recording"))
    } catch (e: Exception) {
        Toast.makeText(context, "Could not share video: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun RecordingCardItem(
    item: RecordingItem,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() },
        colors = CardDefaults.cardColors(containerColor = ViperSurfaceCard),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF162030))
                        .clickable { onPlay() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = ViperGreen,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column {
                    Text(
                        text = item.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    val dateFormatted = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault()).format(Date(item.timestamp))
                    Text(
                        text = "$dateFormatted • ${item.resolution} • ${item.durationSeconds}s",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "${String.format(Locale.getDefault(), "%.1f", item.fileSizeBytes / (1024.0 * 1024.0))} MB • Movies/VIPER STUDIO",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onPlay, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = ViperGreen, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = ViperCyan, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
